#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <opencv2/opencv.hpp>
using namespace std;
// g++ -std=c++17 -Wall -Wextra -g -Iinclude -ID:/software/opencv/mingw/install/include -c src/main.cpp -o src/main.o  -LD:/software/opencv/mingw/install/x64/mingw/lib -llibopencv_imgcodecs420 -llibopencv_imgproc420 -llibopencv_highgui420 -llibopencv_core420
// g++ -std=c++17 -Wall -Wextra -g -Iinclude -ID:/software/opencv/mingw/install/include -o output\main.exe src/main.o  -LD:/software/opencv/mingw/install/x64/mingw/lib -llibopencv_imgcodecs420 -llibopencv_imgproc420 -llibopencv_highgui420 -llibopencv_core420
// libopencv_core420

int main()
{
  // cv::imread => libopencv_imgcodecs420
  cv::Mat a = cv::imread("C:\\Users\\klein.zhou\\Desktop\\practice\\opencv\\project\\webgl24glb.jpg");
  // cv::imshow => libopencv_highgui420
  cv::imshow("OpenCV Demo", a);
  // cv::waitKey => libopencv_highgui420
  cv::waitKey(0);

  return 0;
}
